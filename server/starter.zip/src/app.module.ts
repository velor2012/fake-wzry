import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { PostController } from './post/post.controller';
import { PostModule } from './post/post.module';
import {TypegooseModule } from 'nestjs-typegoose';

const config = require('../config');
let { mongodb, host, port } = config;
let { username, password, db, mongo_port, mongo_host } = mongodb;
@Module({
  imports: [
    TypegooseModule.forRoot(
      `mongodb://${username}:${password}@${mongo_host}:${mongo_port}/${db}`,
      {
        useNewUrlParser: true,
        useFindAndModify: false,
        useCreateIndex: true,
        useUnifiedTopology: true,
      },
    ),
    PostModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
