import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import * as mongoose from 'mongoose';
const consola = require("consola");
const config = require("../config")
let { mongodb, host, port } = config
async function bootstrap() {


  const app = await NestFactory.create(AppModule);
    // 处理跨域
    app.enableCors();
 //swagger
 const options = new DocumentBuilder()
 .setTitle('仿王者荣耀官网项目api')
 .setDescription('The cats API description')
 .setVersion('1.0')
 .addTag('wzry')
 .build();
 const document = SwaggerModule.createDocument(app, options);
   SwaggerModule.setup('api-doc', app, document);
 //end swagger
  await app.listen(`${port}`, `${host}`);
  consola.ready({
    message: `Server listening on http://${host}:${port}`,
    badge: true
  });
}
bootstrap();
